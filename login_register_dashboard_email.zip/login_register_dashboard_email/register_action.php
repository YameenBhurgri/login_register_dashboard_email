<?php
// Include PHPMailer files
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Include Composer's autoload file for PHPMailer

include 'db.php'; // Database connection

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
    $phone = $_POST['phone'];
    $description = $_POST['description'];
    $address = $_POST['address'];

    // Handle Image Upload
    $image = $_FILES['image']['name'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($image);
    move_uploaded_file($_FILES['image']['tmp_name'], $target_file);

    // Insert into Database
    $query = "INSERT INTO users (name, email, password, phone, description, image, address) 
              VALUES ('$name', '$email', '$password', '$phone', '$description', '$image', '$address')";
    if (mysqli_query($conn, $query)) {
        // Send the confirmation email using PHPMailer
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';  // Set the SMTP server to send email
            $mail->SMTPAuth = true;
            $mail->Username = 'your_email@gmail.com'; // Your Gmail address (sender)
            $mail->Password = 'your_email_password'; // Your Gmail password (or app password)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('your_email@gmail.com', 'Your Platform'); // Set the sender's email
            $mail->addAddress('yaminbhurgri360@gmail.com', 'Yamin Bhurgri'); // Receiver email (you)

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your Account Has Been Created Successfully';
            $mail->Body    = "Hello $name,<br><br>Thank you for registering with us! Your account has been successfully created.<br><br>Best regards,<br>Your Platform Team";

            $mail->send();
            echo "Registration successful! A confirmation email has been sent to your email address.";
        } catch (Exception $e) {
            echo "Registration successful, but we couldn't send a confirmation email. Mailer Error: {$mail->ErrorInfo}";
        }

        header("Location: login.php"); // Redirect to login page
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!-- composer require phpmailer/phpmailer
 -->
<!-- CREATE TABLE users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    description TEXT,
    image VARCHAR(255),
    address TEXT
);
 -->